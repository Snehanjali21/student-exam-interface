const mongoose = require('mongoose');
const User = require('./models/User');
const Question = require('./models/Question');
require('dotenv').config({ path: './config.env' });

const sampleQuestions = [
  {
    question: "What is the capital of France?",
    options: ["London", "Berlin", "Paris", "Madrid"],
    correctAnswer: 2,
    category: "Geography",
    difficulty: "easy",
    explanation: "Paris is the capital and largest city of France.",
    tags: ["geography", "europe", "capitals"]
  },
  {
    question: "Which programming language is known as the 'language of the web'?",
    options: ["Python", "Java", "JavaScript", "C++"],
    correctAnswer: 2,
    category: "Programming",
    difficulty: "easy",
    explanation: "JavaScript is the primary language used for web development.",
    tags: ["programming", "web", "javascript"]
  },
  {
    question: "What is the chemical symbol for gold?",
    options: ["Ag", "Au", "Fe", "Cu"],
    correctAnswer: 1,
    category: "Science",
    difficulty: "medium",
    explanation: "Au comes from the Latin word 'aurum' which means gold.",
    tags: ["chemistry", "elements", "symbols"]
  },
  {
    question: "Who wrote 'Romeo and Juliet'?",
    options: ["Charles Dickens", "William Shakespeare", "Jane Austen", "Mark Twain"],
    correctAnswer: 1,
    category: "Literature",
    difficulty: "easy",
    explanation: "William Shakespeare wrote this famous tragedy in the late 16th century.",
    tags: ["literature", "shakespeare", "drama"]
  },
  {
    question: "What is the largest planet in our solar system?",
    options: ["Mars", "Venus", "Jupiter", "Saturn"],
    correctAnswer: 2,
    category: "Science",
    difficulty: "easy",
    explanation: "Jupiter is the largest planet in our solar system.",
    tags: ["astronomy", "planets", "solar-system"]
  },
  {
    question: "Which of the following is a JavaScript framework?",
    options: ["Django", "React", "Flask", "Express"],
    correctAnswer: 1,
    category: "Programming",
    difficulty: "medium",
    explanation: "React is a JavaScript library for building user interfaces.",
    tags: ["programming", "javascript", "frontend"]
  },
  {
    question: "What year did World War II end?",
    options: ["1943", "1944", "1945", "1946"],
    correctAnswer: 2,
    category: "History",
    difficulty: "medium",
    explanation: "World War II ended in 1945 with the surrender of Germany and Japan.",
    tags: ["history", "world-war-ii", "20th-century"]
  },
  {
    question: "What is the main component of the sun?",
    options: ["Liquid lava", "Molten iron", "Hot gases", "Solid rock"],
    correctAnswer: 2,
    category: "Science",
    difficulty: "medium",
    explanation: "The sun is primarily composed of hydrogen and helium gases.",
    tags: ["astronomy", "sun", "stars"]
  },
  {
    question: "Which country is home to the kangaroo?",
    options: ["New Zealand", "South Africa", "Australia", "India"],
    correctAnswer: 2,
    category: "Geography",
    difficulty: "easy",
    explanation: "Kangaroos are native to Australia.",
    tags: ["geography", "australia", "animals"]
  },
  {
    question: "What is the square root of 144?",
    options: ["10", "11", "12", "13"],
    correctAnswer: 2,
    category: "Mathematics",
    difficulty: "easy",
    explanation: "12 × 12 = 144, so the square root of 144 is 12.",
    tags: ["mathematics", "square-root", "basic-math"]
  },
  {
    question: "Which of these is NOT a programming paradigm?",
    options: ["Object-Oriented", "Functional", "Procedural", "Algorithmic"],
    correctAnswer: 3,
    category: "Programming",
    difficulty: "hard",
    explanation: "Algorithmic is not a programming paradigm. The main paradigms are Object-Oriented, Functional, Procedural, and others.",
    tags: ["programming", "paradigms", "computer-science"]
  },
  {
    question: "What is the largest ocean on Earth?",
    options: ["Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"],
    correctAnswer: 3,
    category: "Geography",
    difficulty: "medium",
    explanation: "The Pacific Ocean is the largest and deepest ocean on Earth.",
    tags: ["geography", "oceans", "earth"]
  },
  {
    question: "Who painted the Mona Lisa?",
    options: ["Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Michelangelo"],
    correctAnswer: 2,
    category: "Art",
    difficulty: "medium",
    explanation: "Leonardo da Vinci painted the Mona Lisa in the early 16th century.",
    tags: ["art", "painting", "renaissance"]
  },
  {
    question: "What is the chemical formula for water?",
    options: ["H2O", "CO2", "O2", "N2"],
    correctAnswer: 0,
    category: "Science",
    difficulty: "easy",
    explanation: "Water is composed of two hydrogen atoms and one oxygen atom (H2O).",
    tags: ["chemistry", "molecules", "water"]
  },
  {
    question: "Which programming language was created by Guido van Rossum?",
    options: ["Java", "Python", "C++", "Ruby"],
    correctAnswer: 1,
    category: "Programming",
    difficulty: "medium",
    explanation: "Guido van Rossum created Python in the late 1980s.",
    tags: ["programming", "python", "languages"]
  }
];

const seedDatabase = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Connected to MongoDB');

    // Clear existing data
    await User.deleteMany({});
    await Question.deleteMany({});
    console.log('Cleared existing data');

    // Create admin user
    const adminUser = new User({
      username: 'admin',
      email: 'admin@exam.com',
      password: 'admin123',
      fullName: 'Administrator',
      role: 'admin'
    });

    await adminUser.save();
    console.log('Created admin user');

    // Create sample student user
    const studentUser = new User({
      username: 'student',
      email: 'student@exam.com',
      password: 'student123',
      fullName: 'John Student',
      role: 'student'
    });

    await studentUser.save();
    console.log('Created sample student user');

    // Create questions
    const questions = sampleQuestions.map(q => ({
      ...q,
      createdBy: adminUser._id
    }));

    await Question.insertMany(questions);
    console.log(`Created ${questions.length} sample questions`);

    console.log('\n=== Database seeded successfully! ===');
    console.log('\nAdmin credentials:');
    console.log('Email: admin@exam.com');
    console.log('Password: admin123');
    console.log('\nStudent credentials:');
    console.log('Email: student@exam.com');
    console.log('Password: student123');

    process.exit(0);
  } catch (error) {
    console.error('Seeding error:', error);
    process.exit(1);
  }
};

seedDatabase(); 