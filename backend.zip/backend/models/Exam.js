const mongoose = require('mongoose');

const examSchema = new mongoose.Schema({
  student: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  questions: [{
    questionId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Question',
      required: true
    },
    question: String,
    options: [String],
    selectedAnswer: {
      type: Number,
      default: null
    },
    correctAnswer: {
      type: Number,
      required: true
    },
    isCorrect: {
      type: Boolean,
      default: false
    }
  }],
  startTime: {
    type: Date,
    required: true,
    default: Date.now
  },
  endTime: {
    type: Date,
    default: null
  },
  duration: {
    type: Number,
    required: true,
    default: 30 // 30 minutes in minutes
  },
  totalQuestions: {
    type: Number,
    required: true
  },
  answeredQuestions: {
    type: Number,
    default: 0
  },
  correctAnswers: {
    type: Number,
    default: 0
  },
  score: {
    type: Number,
    default: 0
  },
  percentage: {
    type: Number,
    default: 0
  },
  status: {
    type: String,
    enum: ['in-progress', 'completed', 'timeout'],
    default: 'in-progress'
  },
  category: {
    type: String,
    required: true
  },
  difficulty: {
    type: String,
    enum: ['easy', 'medium', 'hard'],
    default: 'medium'
  }
}, {
  timestamps: true
});

// Calculate score and percentage
examSchema.methods.calculateResults = function() {
  this.answeredQuestions = this.questions.filter(q => q.selectedAnswer !== null).length;
  this.correctAnswers = this.questions.filter(q => q.isCorrect).length;
  this.score = this.correctAnswers;
  this.percentage = this.totalQuestions > 0 ? (this.correctAnswers / this.totalQuestions) * 100 : 0;
  
  return {
    score: this.score,
    totalQuestions: this.totalQuestions,
    answeredQuestions: this.answeredQuestions,
    correctAnswers: this.correctAnswers,
    percentage: this.percentage
  };
};

// Check if exam is timed out
examSchema.methods.isTimedOut = function() {
  const now = new Date();
  const timeElapsed = (now - this.startTime) / (1000 * 60); // in minutes
  return timeElapsed >= this.duration;
};

// Get remaining time in seconds
examSchema.methods.getRemainingTime = function() {
  const now = new Date();
  const timeElapsed = (now - this.startTime) / 1000; // in seconds
  const totalTime = this.duration * 60; // convert to seconds
  const remaining = Math.max(0, totalTime - timeElapsed);
  return Math.floor(remaining);
};

// Index for efficient querying
examSchema.index({ student: 1, status: 1, createdAt: -1 });
examSchema.index({ startTime: 1, status: 1 });

module.exports = mongoose.model('Exam', examSchema); 