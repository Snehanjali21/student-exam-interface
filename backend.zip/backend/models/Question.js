const mongoose = require('mongoose');

const questionSchema = new mongoose.Schema({
  question: {
    type: String,
    required: [true, 'Question text is required'],
    trim: true,
    minlength: [10, 'Question must be at least 10 characters long']
  },
  options: {
    type: [String],
    required: [true, 'Options are required'],
    validate: {
      validator: function(options) {
        return options.length >= 2 && options.length <= 6;
      },
      message: 'Question must have between 2 and 6 options'
    }
  },
  correctAnswer: {
    type: Number,
    required: [true, 'Correct answer index is required'],
    validate: {
      validator: function(value) {
        return value >= 0 && value < this.options.length;
      },
      message: 'Correct answer index must be within the options range'
    }
  },
  category: {
    type: String,
    required: [true, 'Category is required'],
    trim: true
  },
  difficulty: {
    type: String,
    enum: ['easy', 'medium', 'hard'],
    default: 'medium'
  },
  explanation: {
    type: String,
    trim: true,
    maxlength: [500, 'Explanation cannot exceed 500 characters']
  },
  tags: [{
    type: String,
    trim: true
  }],
  isActive: {
    type: Boolean,
    default: true
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
}, {
  timestamps: true
});

// Index for efficient querying
questionSchema.index({ category: 1, difficulty: 1, isActive: 1 });

// Method to get random questions
questionSchema.statics.getRandomQuestions = async function(count, category = null, difficulty = null) {
  const matchStage = { isActive: true };
  
  if (category) matchStage.category = category;
  if (difficulty) matchStage.difficulty = difficulty;
  
  return await this.aggregate([
    { $match: matchStage },
    { $sample: { size: count } },
    { $project: { 
      question: 1, 
      options: 1, 
      category: 1, 
      difficulty: 1,
      explanation: 1,
      tags: 1
    }}
  ]);
};

module.exports = mongoose.model('Question', questionSchema); 