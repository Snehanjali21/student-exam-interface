const express = require('express');
const { body, validationResult } = require('express-validator');
const Question = require('../models/Question');
const { auth, requireRole } = require('../middleware/auth');

const router = express.Router();

// Get all questions (admin only)
router.get('/', auth, requireRole(['admin']), async (req, res) => {
  try {
    const { page = 1, limit = 20, category, difficulty, search } = req.query;
    const skip = (page - 1) * limit;

    const filter = { isActive: true };
    
    if (category) filter.category = category;
    if (difficulty) filter.difficulty = difficulty;
    if (search) {
      filter.$or = [
        { question: { $regex: search, $options: 'i' } },
        { category: { $regex: search, $options: 'i' } }
      ];
    }

    const questions = await Question.find(filter)
      .populate('createdBy', 'username fullName')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Question.countDocuments(filter);

    res.json({
      questions,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(total / limit),
        totalQuestions: total
      }
    });

  } catch (error) {
    console.error('Get questions error:', error);
    res.status(500).json({ 
      error: 'Failed to get questions',
      message: error.message 
    });
  }
});

// Get question categories
router.get('/categories', async (req, res) => {
  try {
    const categories = await Question.distinct('category', { isActive: true });
    res.json({ categories });
  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({ 
      error: 'Failed to get categories',
      message: error.message 
    });
  }
});

// Create new question (admin only)
router.post('/', auth, requireRole(['admin']), [
  body('question')
    .isLength({ min: 10 })
    .withMessage('Question must be at least 10 characters long'),
  body('options')
    .isArray({ min: 2, max: 6 })
    .withMessage('Question must have between 2 and 6 options'),
  body('options.*')
    .notEmpty()
    .withMessage('All options must have content'),
  body('correctAnswer')
    .isInt({ min: 0 })
    .withMessage('Correct answer must be a valid option index'),
  body('category')
    .notEmpty()
    .withMessage('Category is required'),
  body('difficulty')
    .isIn(['easy', 'medium', 'hard'])
    .withMessage('Difficulty must be easy, medium, or hard')
], async (req, res) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        error: 'Validation failed',
        details: errors.array() 
      });
    }

    const { question, options, correctAnswer, category, difficulty, explanation, tags } = req.body;

    // Validate correct answer index
    if (correctAnswer >= options.length) {
      return res.status(400).json({ 
        error: 'Correct answer index must be within the options range' 
      });
    }

    const newQuestion = new Question({
      question,
      options,
      correctAnswer,
      category,
      difficulty,
      explanation,
      tags,
      createdBy: req.user._id
    });

    await newQuestion.save();

    res.status(201).json({
      message: 'Question created successfully',
      question: newQuestion
    });

  } catch (error) {
    console.error('Create question error:', error);
    res.status(500).json({ 
      error: 'Failed to create question',
      message: error.message 
    });
  }
});

// Update question (admin only)
router.put('/:id', auth, requireRole(['admin']), [
  body('question')
    .optional()
    .isLength({ min: 10 })
    .withMessage('Question must be at least 10 characters long'),
  body('options')
    .optional()
    .isArray({ min: 2, max: 6 })
    .withMessage('Question must have between 2 and 6 options'),
  body('options.*')
    .optional()
    .notEmpty()
    .withMessage('All options must have content'),
  body('correctAnswer')
    .optional()
    .isInt({ min: 0 })
    .withMessage('Correct answer must be a valid option index'),
  body('category')
    .optional()
    .notEmpty()
    .withMessage('Category cannot be empty'),
  body('difficulty')
    .optional()
    .isIn(['easy', 'medium', 'hard'])
    .withMessage('Difficulty must be easy, medium, or hard')
], async (req, res) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        error: 'Validation failed',
        details: errors.array() 
      });
    }

    const { id } = req.params;
    const updates = req.body;

    // Validate correct answer if options are being updated
    if (updates.options && updates.correctAnswer !== undefined) {
      if (updates.correctAnswer >= updates.options.length) {
        return res.status(400).json({ 
          error: 'Correct answer index must be within the options range' 
        });
      }
    }

    const question = await Question.findByIdAndUpdate(
      id,
      updates,
      { new: true, runValidators: true }
    );

    if (!question) {
      return res.status(404).json({ error: 'Question not found' });
    }

    res.json({
      message: 'Question updated successfully',
      question
    });

  } catch (error) {
    console.error('Update question error:', error);
    res.status(500).json({ 
      error: 'Failed to update question',
      message: error.message 
    });
  }
});

// Delete question (admin only)
router.delete('/:id', auth, requireRole(['admin']), async (req, res) => {
  try {
    const { id } = req.params;

    const question = await Question.findByIdAndUpdate(
      id,
      { isActive: false },
      { new: true }
    );

    if (!question) {
      return res.status(404).json({ error: 'Question not found' });
    }

    res.json({
      message: 'Question deleted successfully'
    });

  } catch (error) {
    console.error('Delete question error:', error);
    res.status(500).json({ 
      error: 'Failed to delete question',
      message: error.message 
    });
  }
});

// Get question by ID (admin only)
router.get('/:id', auth, requireRole(['admin']), async (req, res) => {
  try {
    const { id } = req.params;

    const question = await Question.findById(id)
      .populate('createdBy', 'username fullName');

    if (!question) {
      return res.status(404).json({ error: 'Question not found' });
    }

    res.json({ question });

  } catch (error) {
    console.error('Get question error:', error);
    res.status(500).json({ 
      error: 'Failed to get question',
      message: error.message 
    });
  }
});

module.exports = router; 