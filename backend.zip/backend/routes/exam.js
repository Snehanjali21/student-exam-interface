const express = require('express');
const { body, validationResult } = require('express-validator');
const Exam = require('../models/Exam');
const Question = require('../models/Question');
const { auth, requireRole } = require('../middleware/auth');

const router = express.Router();

// Start a new exam
router.post('/start', auth, [
  body('category')
    .notEmpty()
    .withMessage('Category is required'),
  body('difficulty')
    .optional()
    .isIn(['easy', 'medium', 'hard'])
    .withMessage('Difficulty must be easy, medium, or hard'),
  body('questionCount')
    .optional()
    .isInt({ min: 5, max: 50 })
    .withMessage('Question count must be between 5 and 50')
], async (req, res) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        error: 'Validation failed',
        details: errors.array() 
      });
    }

    const { category, difficulty = 'medium', questionCount = 20 } = req.body;

    // Check if user has an active exam
    const activeExam = await Exam.findOne({
      student: req.user._id,
      status: 'in-progress'
    });

    if (activeExam) {
      return res.status(400).json({ 
        error: 'You already have an active exam in progress' 
      });
    }

    // Get random questions
    const questions = await Question.getRandomQuestions(questionCount, category, difficulty);
    
    if (questions.length < questionCount) {
      return res.status(400).json({ 
        error: `Not enough questions available for category: ${category} and difficulty: ${difficulty}` 
      });
    }

    // Create exam with questions (without correct answers for security)
    const examQuestions = questions.map(q => ({
      questionId: q._id,
      question: q.question,
      options: q.options,
      correctAnswer: q.correctAnswer
    }));

    const exam = new Exam({
      student: req.user._id,
      questions: examQuestions,
      totalQuestions: questionCount,
      category,
      difficulty
    });

    await exam.save();

    // Return exam without correct answers
    const examForStudent = {
      _id: exam._id,
      questions: exam.questions.map(q => ({
        questionId: q.questionId,
        question: q.question,
        options: q.options,
        selectedAnswer: q.selectedAnswer
      })),
      startTime: exam.startTime,
      duration: exam.duration,
      totalQuestions: exam.totalQuestions,
      category: exam.category,
      difficulty: exam.difficulty
    };

    res.status(201).json({
      message: 'Exam started successfully',
      exam: examForStudent
    });

  } catch (error) {
    console.error('Start exam error:', error);
    res.status(500).json({ 
      error: 'Failed to start exam',
      message: error.message 
    });
  }
});

// Get current exam
router.get('/current', auth, async (req, res) => {
  try {
    const exam = await Exam.findOne({
      student: req.user._id,
      status: 'in-progress'
    });

    if (!exam) {
      return res.status(404).json({ error: 'No active exam found' });
    }

    // Check if exam is timed out
    if (exam.isTimedOut()) {
      exam.status = 'timeout';
      exam.endTime = new Date();
      await exam.save();
      
      return res.status(400).json({ 
        error: 'Exam has timed out',
        examId: exam._id 
      });
    }

    // Return exam without correct answers
    const examForStudent = {
      _id: exam._id,
      questions: exam.questions.map(q => ({
        questionId: q.questionId,
        question: q.question,
        options: q.options,
        selectedAnswer: q.selectedAnswer
      })),
      startTime: exam.startTime,
      duration: exam.duration,
      totalQuestions: exam.totalQuestions,
      category: exam.category,
      difficulty: exam.difficulty,
      remainingTime: exam.getRemainingTime()
    };

    res.json({
      exam: examForStudent
    });

  } catch (error) {
    console.error('Get current exam error:', error);
    res.status(500).json({ 
      error: 'Failed to get current exam',
      message: error.message 
    });
  }
});

// Submit answer for a question
router.post('/answer', auth, [
  body('examId')
    .notEmpty()
    .withMessage('Exam ID is required'),
  body('questionId')
    .notEmpty()
    .withMessage('Question ID is required'),
  body('selectedAnswer')
    .isInt({ min: 0 })
    .withMessage('Selected answer must be a valid option index')
], async (req, res) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        error: 'Validation failed',
        details: errors.array() 
      });
    }

    const { examId, questionId, selectedAnswer } = req.body;

    const exam = await Exam.findOne({
      _id: examId,
      student: req.user._id,
      status: 'in-progress'
    });

    if (!exam) {
      return res.status(404).json({ error: 'Exam not found or not active' });
    }

    // Check if exam is timed out
    if (exam.isTimedOut()) {
      exam.status = 'timeout';
      exam.endTime = new Date();
      await exam.save();
      
      return res.status(400).json({ 
        error: 'Exam has timed out' 
      });
    }

    // Find and update the question
    const question = exam.questions.id(questionId);
    if (!question) {
      return res.status(404).json({ error: 'Question not found' });
    }

    // Validate selected answer
    if (selectedAnswer >= question.options.length) {
      return res.status(400).json({ error: 'Invalid answer option' });
    }

    question.selectedAnswer = selectedAnswer;
    question.isCorrect = selectedAnswer === question.correctAnswer;

    await exam.save();

    res.json({
      message: 'Answer submitted successfully',
      isCorrect: question.isCorrect
    });

  } catch (error) {
    console.error('Submit answer error:', error);
    res.status(500).json({ 
      error: 'Failed to submit answer',
      message: error.message 
    });
  }
});

// Submit exam
router.post('/submit', auth, [
  body('examId')
    .notEmpty()
    .withMessage('Exam ID is required')
], async (req, res) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        error: 'Validation failed',
        details: errors.array() 
      });
    }

    const { examId } = req.body;

    const exam = await Exam.findOne({
      _id: examId,
      student: req.user._id,
      status: 'in-progress'
    });

    if (!exam) {
      return res.status(404).json({ error: 'Exam not found or not active' });
    }

    // Mark exam as completed
    exam.status = 'completed';
    exam.endTime = new Date();

    // Calculate results
    const results = exam.calculateResults();

    await exam.save();

    res.json({
      message: 'Exam submitted successfully',
      results: {
        score: results.score,
        totalQuestions: results.totalQuestions,
        answeredQuestions: results.answeredQuestions,
        correctAnswers: results.correctAnswers,
        percentage: results.percentage
      }
    });

  } catch (error) {
    console.error('Submit exam error:', error);
    res.status(500).json({ 
      error: 'Failed to submit exam',
      message: error.message 
    });
  }
});

// Get exam history
router.get('/history', auth, async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const skip = (page - 1) * limit;

    const exams = await Exam.find({
      student: req.user._id,
      status: { $in: ['completed', 'timeout'] }
    })
    .select('startTime endTime totalQuestions score percentage category difficulty status')
    .sort({ startTime: -1 })
    .skip(skip)
    .limit(parseInt(limit));

    const total = await Exam.countDocuments({
      student: req.user._id,
      status: { $in: ['completed', 'timeout'] }
    });

    res.json({
      exams,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(total / limit),
        totalExams: total
      }
    });

  } catch (error) {
    console.error('Get exam history error:', error);
    res.status(500).json({ 
      error: 'Failed to get exam history',
      message: error.message 
    });
  }
});

// Get specific exam result
router.get('/result/:examId', auth, async (req, res) => {
  try {
    const { examId } = req.params;

    const exam = await Exam.findOne({
      _id: examId,
      student: req.user._id,
      status: { $in: ['completed', 'timeout'] }
    });

    if (!exam) {
      return res.status(404).json({ error: 'Exam not found' });
    }

    // Return exam with correct answers for review
    const examResult = {
      _id: exam._id,
      startTime: exam.startTime,
      endTime: exam.endTime,
      duration: exam.duration,
      totalQuestions: exam.totalQuestions,
      answeredQuestions: exam.answeredQuestions,
      correctAnswers: exam.correctAnswers,
      score: exam.score,
      percentage: exam.percentage,
      category: exam.category,
      difficulty: exam.difficulty,
      status: exam.status,
      questions: exam.questions.map(q => ({
        question: q.question,
        options: q.options,
        selectedAnswer: q.selectedAnswer,
        correctAnswer: q.correctAnswer,
        isCorrect: q.isCorrect
      }))
    };

    res.json({
      exam: examResult
    });

  } catch (error) {
    console.error('Get exam result error:', error);
    res.status(500).json({ 
      error: 'Failed to get exam result',
      message: error.message 
    });
  }
});

module.exports = router; 