import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';
import toast from 'react-hot-toast';
import { FaPlay, FaHistory, FaUser, FaClock, FaTrophy } from 'react-icons/fa';
import './Dashboard.css';

const Dashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [examStats, setExamStats] = useState({
    totalExams: 0,
    averageScore: 0,
    bestScore: 0
  });

  useEffect(() => {
    fetchCategories();
    fetchExamStats();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await axios.get('/api/questions/categories');
      setCategories(response.data.categories);
    } catch (error) {
      console.error('Error fetching categories:', error);
      toast.error('Failed to load categories');
    } finally {
      setLoading(false);
    }
  };

  const fetchExamStats = async () => {
    try {
      const response = await axios.get('/api/exam/history?limit=100');
      const exams = response.data.exams;
      
      if (exams.length > 0) {
        const totalExams = exams.length;
        const totalScore = exams.reduce((sum, exam) => sum + exam.percentage, 0);
        const averageScore = Math.round(totalScore / totalExams);
        const bestScore = Math.max(...exams.map(exam => exam.percentage));
        
        setExamStats({
          totalExams,
          averageScore,
          bestScore
        });
      }
    } catch (error) {
      console.error('Error fetching exam stats:', error);
    }
  };

  const startExam = async (category, difficulty = 'medium') => {
    try {
      const response = await axios.post('/api/exam/start', {
        category,
        difficulty,
        questionCount: 20
      });

      toast.success('Exam started successfully!');
      navigate('/exam');
    } catch (error) {
      const message = error.response?.data?.error || 'Failed to start exam';
      toast.error(message);
    }
  };

  if (loading) {
    return (
      <div className="loading">
        <div>Loading dashboard...</div>
      </div>
    );
  }

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Welcome back, {user?.fullName || user?.username}!</h1>
        <p>Ready to test your knowledge? Choose a category and start your exam.</p>
      </div>

      <div className="dashboard-stats">
        <div className="stat-card">
          <FaTrophy className="stat-icon" />
          <div className="stat-content">
            <h3>{examStats.totalExams}</h3>
            <p>Total Exams</p>
          </div>
        </div>
        <div className="stat-card">
          <FaUser className="stat-icon" />
          <div className="stat-content">
            <h3>{examStats.averageScore}%</h3>
            <p>Average Score</p>
          </div>
        </div>
        <div className="stat-card">
          <FaClock className="stat-icon" />
          <div className="stat-content">
            <h3>{examStats.bestScore}%</h3>
            <p>Best Score</p>
          </div>
        </div>
      </div>

      <div className="dashboard-content">
        <div className="exam-categories">
          <h2>Available Categories</h2>
          <div className="categories-grid">
            {categories.map((category) => (
              <div key={category} className="category-card">
                <h3>{category}</h3>
                <div className="difficulty-buttons">
                  <button
                    className="btn btn-primary"
                    onClick={() => startExam(category, 'easy')}
                  >
                    <FaPlay className="btn-icon" />
                    Easy
                  </button>
                  <button
                    className="btn btn-primary"
                    onClick={() => startExam(category, 'medium')}
                  >
                    <FaPlay className="btn-icon" />
                    Medium
                  </button>
                  <button
                    className="btn btn-primary"
                    onClick={() => startExam(category, 'hard')}
                  >
                    <FaPlay className="btn-icon" />
                    Hard
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="quick-actions">
          <h2>Quick Actions</h2>
          <div className="action-buttons">
            <button
              className="btn btn-secondary"
              onClick={() => navigate('/history')}
            >
              <FaHistory className="btn-icon" />
              View Exam History
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard; 