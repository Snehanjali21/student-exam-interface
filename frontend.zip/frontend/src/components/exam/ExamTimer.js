import React, { useState, useEffect } from 'react';
import { FaClock } from 'react-icons/fa';

const ExamTimer = ({ duration, onTimeUp, remainingTime }) => {
  const [timeLeft, setTimeLeft] = useState(remainingTime || duration);

  useEffect(() => {
    if (timeLeft <= 0) {
      onTimeUp();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          onTimeUp();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, onTimeUp]);

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getTimeColor = () => {
    if (timeLeft <= 300) return '#dc3545'; // Red for last 5 minutes
    if (timeLeft <= 600) return '#ffc107'; // Yellow for last 10 minutes
    return '#28a745'; // Green for normal time
  };

  return (
    <div className="exam-timer">
      <FaClock className="timer-icon" />
      <span 
        className="timer-text"
        style={{ color: getTimeColor() }}
      >
        {formatTime(timeLeft)}
      </span>
    </div>
  );
};

export default ExamTimer; 