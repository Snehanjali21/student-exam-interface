import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';
import { FaCheck, FaTimes, FaTrophy, FaClock, FaChartBar, FaHome } from 'react-icons/fa';
import './ExamResult.css';

const ExamResult = () => {
  const { examId } = useParams();
  const navigate = useNavigate();
  const [exam, setExam] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showReview, setShowReview] = useState(false);

  useEffect(() => {
    fetchExamResult();
  }, [examId]);

  const fetchExamResult = async () => {
    try {
      const response = await axios.get(`/api/exam/result/${examId}`);
      setExam(response.data.exam);
    } catch (error) {
      toast.error('Failed to load exam result');
      navigate('/dashboard');
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (percentage) => {
    if (percentage >= 80) return '#28a745';
    if (percentage >= 60) return '#ffc107';
    return '#dc3545';
  };

  const getScoreMessage = (percentage) => {
    if (percentage >= 90) return 'Excellent!';
    if (percentage >= 80) return 'Great job!';
    if (percentage >= 70) return 'Good work!';
    if (percentage >= 60) return 'Not bad!';
    if (percentage >= 50) return 'Keep practicing!';
    return 'Need more practice!';
  };

  if (loading) {
    return (
      <div className="loading">
        <div>Loading exam result...</div>
      </div>
    );
  }

  if (!exam) {
    return (
      <div className="exam-error">
        <h2>Exam not found</h2>
        <button 
          className="btn btn-primary"
          onClick={() => navigate('/dashboard')}
        >
          Go to Dashboard
        </button>
      </div>
    );
  }

  const formatDuration = (minutes) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="exam-result">
      <div className="result-header">
        <h1>Exam Results</h1>
        <div className="result-summary">
          <div className="score-card">
            <FaTrophy className="score-icon" />
            <div className="score-content">
              <h2 
                className="score-percentage"
                style={{ color: getScoreColor(exam.percentage) }}
              >
                {exam.percentage.toFixed(1)}%
              </h2>
              <p className="score-message">{getScoreMessage(exam.percentage)}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="result-details">
        <div className="detail-cards">
          <div className="detail-card">
            <FaChartBar className="detail-icon" />
            <div className="detail-content">
              <h3>{exam.correctAnswers}</h3>
              <p>Correct Answers</p>
            </div>
          </div>
          <div className="detail-card">
            <FaClock className="detail-icon" />
            <div className="detail-content">
              <h3>{exam.totalQuestions}</h3>
              <p>Total Questions</p>
            </div>
          </div>
          <div className="detail-card">
            <FaCheck className="detail-icon" />
            <div className="detail-content">
              <h3>{exam.answeredQuestions}</h3>
              <p>Answered</p>
            </div>
          </div>
        </div>

        <div className="exam-info">
          <h3>Exam Information</h3>
          <div className="info-grid">
            <div className="info-item">
              <strong>Category:</strong> {exam.category}
            </div>
            <div className="info-item">
              <strong>Difficulty:</strong> {exam.difficulty}
            </div>
            <div className="info-item">
              <strong>Duration:</strong> {formatDuration(exam.duration)}
            </div>
            <div className="info-item">
              <strong>Started:</strong> {formatDate(exam.startTime)}
            </div>
            <div className="info-item">
              <strong>Completed:</strong> {formatDate(exam.endTime)}
            </div>
            <div className="info-item">
              <strong>Status:</strong> {exam.status}
            </div>
          </div>
        </div>
      </div>

      <div className="result-actions">
        <button
          className="btn btn-primary"
          onClick={() => setShowReview(!showReview)}
        >
          {showReview ? 'Hide Review' : 'Show Review'}
        </button>
        <button
          className="btn btn-secondary"
          onClick={() => navigate('/dashboard')}
        >
          <FaHome />
          Back to Dashboard
        </button>
      </div>

      {showReview && (
        <div className="exam-review">
          <h3>Question Review</h3>
          <div className="questions-review">
            {exam.questions.map((question, index) => (
              <div key={index} className="review-question">
                <div className="question-header">
                  <span className="question-number">Question {index + 1}</span>
                  <span className={`question-status ${question.isCorrect ? 'correct' : 'incorrect'}`}>
                    {question.isCorrect ? (
                      <>
                        <FaCheck /> Correct
                      </>
                    ) : (
                      <>
                        <FaTimes /> Incorrect
                      </>
                    )}
                  </span>
                </div>
                
                <div className="question-content">
                  <h4>{question.question}</h4>
                  
                  <div className="options-review">
                    {question.options.map((option, optionIndex) => (
                      <div
                        key={optionIndex}
                        className={`option-review ${
                          optionIndex === question.correctAnswer ? 'correct-answer' : ''
                        } ${
                          optionIndex === question.selectedAnswer && 
                          question.selectedAnswer !== question.correctAnswer ? 'wrong-answer' : ''
                        }`}
                      >
                        <span className="option-label">
                          {String.fromCharCode(65 + optionIndex)}.
                        </span>
                        {option}
                        {optionIndex === question.correctAnswer && (
                          <FaCheck className="correct-icon" />
                        )}
                        {optionIndex === question.selectedAnswer && 
                         question.selectedAnswer !== question.correctAnswer && (
                          <FaTimes className="incorrect-icon" />
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ExamResult; 