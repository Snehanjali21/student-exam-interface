import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';
import { FaEye, FaClock, FaTrophy, FaChartBar } from 'react-icons/fa';
import './ExamHistory.css';

const ExamHistory = () => {
  const navigate = useNavigate();
  const [exams, setExams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalExams, setTotalExams] = useState(0);

  useEffect(() => {
    fetchExamHistory();
  }, [currentPage]);

  const fetchExamHistory = async () => {
    try {
      const response = await axios.get(`/api/exam/history?page=${currentPage}&limit=10`);
      setExams(response.data.exams);
      setTotalPages(response.data.pagination.totalPages);
      setTotalExams(response.data.pagination.totalExams);
    } catch (error) {
      toast.error('Failed to load exam history');
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (percentage) => {
    if (percentage >= 80) return '#28a745';
    if (percentage >= 60) return '#ffc107';
    return '#dc3545';
  };

  const getScoreMessage = (percentage) => {
    if (percentage >= 90) return 'Excellent';
    if (percentage >= 80) return 'Great';
    if (percentage >= 70) return 'Good';
    if (percentage >= 60) return 'Fair';
    if (percentage >= 50) return 'Poor';
    return 'Very Poor';
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatDuration = (minutes) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  const handleViewResult = (examId) => {
    navigate(`/exam/result/${examId}`);
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  if (loading) {
    return (
      <div className="loading">
        <div>Loading exam history...</div>
      </div>
    );
  }

  return (
    <div className="exam-history">
      <div className="history-header">
        <h1>Exam History</h1>
        <p>View your past exam results and performance</p>
      </div>

      {exams.length === 0 ? (
        <div className="empty-history">
          <FaChartBar className="empty-icon" />
          <h3>No exams taken yet</h3>
          <p>Start your first exam from the dashboard to see your history here.</p>
          <button 
            className="btn btn-primary"
            onClick={() => navigate('/dashboard')}
          >
            Go to Dashboard
          </button>
        </div>
      ) : (
        <>
          <div className="history-stats">
            <div className="stat-item">
              <FaTrophy className="stat-icon" />
              <div className="stat-content">
                <h3>{totalExams}</h3>
                <p>Total Exams</p>
              </div>
            </div>
            <div className="stat-item">
              <FaChartBar className="stat-icon" />
              <div className="stat-content">
                <h3>
                  {exams.length > 0 
                    ? Math.round(exams.reduce((sum, exam) => sum + exam.percentage, 0) / exams.length)
                    : 0
                  }%
                </h3>
                <p>Average Score</p>
              </div>
            </div>
            <div className="stat-item">
              <FaClock className="stat-icon" />
              <div className="stat-content">
                <h3>
                  {exams.length > 0 
                    ? Math.max(...exams.map(exam => exam.percentage))
                    : 0
                  }%
                </h3>
                <p>Best Score</p>
              </div>
            </div>
          </div>

          <div className="exams-list">
            {exams.map((exam) => (
              <div key={exam._id} className="exam-item">
                <div className="exam-info">
                  <div className="exam-main">
                    <h3>{exam.category}</h3>
                    <p className="exam-details">
                      Difficulty: {exam.difficulty} | 
                      Questions: {exam.totalQuestions} | 
                      Duration: {formatDuration(exam.duration)}
                    </p>
                    <p className="exam-date">
                      {formatDate(exam.startTime)}
                    </p>
                  </div>
                  
                  <div className="exam-score">
                    <div 
                      className="score-circle"
                      style={{ 
                        background: `conic-gradient(${getScoreColor(exam.percentage)} ${exam.percentage * 3.6}deg, #e9ecef ${exam.percentage * 3.6}deg)` 
                      }}
                    >
                      <div className="score-inner">
                        <span className="score-percentage">
                          {exam.percentage.toFixed(1)}%
                        </span>
                        <span className="score-label">
                          {getScoreMessage(exam.percentage)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="exam-stats">
                  <div className="stat">
                    <span className="stat-label">Correct:</span>
                    <span className="stat-value">{exam.correctAnswers}</span>
                  </div>
                  <div className="stat">
                    <span className="stat-label">Answered:</span>
                    <span className="stat-value">{exam.answeredQuestions}</span>
                  </div>
                  <div className="stat">
                    <span className="stat-label">Status:</span>
                    <span className={`stat-value status-${exam.status}`}>
                      {exam.status}
                    </span>
                  </div>
                </div>

                <div className="exam-actions">
                  <button
                    className="btn btn-primary"
                    onClick={() => handleViewResult(exam._id)}
                  >
                    <FaEye />
                    View Result
                  </button>
                </div>
              </div>
            ))}
          </div>

          {totalPages > 1 && (
            <div className="pagination">
              <button
                className="btn btn-secondary"
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
              >
                Previous
              </button>
              
              <div className="page-info">
                Page {currentPage} of {totalPages}
              </div>
              
              <button
                className="btn btn-secondary"
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
              >
                Next
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default ExamHistory; 