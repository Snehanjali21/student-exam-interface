import React, { useState } from 'react';
import { FaCheckCircle, FaCircle } from 'react-icons/fa';

const QuestionCard = ({ question, questionNumber, onAnswerSelect, disabled }) => {
  const [selectedAnswer, setSelectedAnswer] = useState(question.selectedAnswer);

  const handleOptionClick = (optionIndex) => {
    if (disabled) return;
    
    setSelectedAnswer(optionIndex);
    onAnswerSelect(question.questionId, optionIndex);
  };

  return (
    <div className="question-card">
      <div className="question-header">
        <span className="question-number">Question {questionNumber}</span>
      </div>
      
      <div className="question-content">
        <h3 className="question-text">{question.question}</h3>
        
        <div className="options-list">
          {question.options.map((option, index) => (
            <div
              key={index}
              className={`option-item ${selectedAnswer === index ? 'selected' : ''}`}
              onClick={() => handleOptionClick(index)}
            >
              <div className="option-radio">
                {selectedAnswer === index ? (
                  <FaCheckCircle className="radio-icon selected" />
                ) : (
                  <FaCircle className="radio-icon" />
                )}
              </div>
              <div className="option-text">
                <span className="option-label">
                  {String.fromCharCode(65 + index)}.
                </span>
                {option}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default QuestionCard; 