import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';
import { FaChevronLeft, FaChevronRight, FaClock, FaCheck, FaTimes } from 'react-icons/fa';
import ExamTimer from './ExamTimer';
import QuestionCard from './QuestionCard';
import './ExamInterface.css';

const ExamInterface = () => {
  const navigate = useNavigate();
  const [exam, setExam] = useState(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [timeUp, setTimeUp] = useState(false);

  useEffect(() => {
    loadCurrentExam();
  }, []);

  const loadCurrentExam = async () => {
    try {
      const response = await axios.get('/api/exam/current');
      setExam(response.data.exam);
    } catch (error) {
      if (error.response?.status === 404) {
        toast.error('No active exam found. Please start a new exam from the dashboard.');
        navigate('/dashboard');
        return;
      }
      if (error.response?.data?.error === 'Exam has timed out') {
        toast.error('Your exam has timed out. Redirecting to results...');
        navigate(`/exam/result/${error.response.data.examId}`);
        return;
      }
      toast.error('Failed to load exam');
      navigate('/dashboard');
    } finally {
      setLoading(false);
    }
  };

  const handleAnswerSelect = async (questionId, selectedAnswer) => {
    if (!exam || timeUp) return;

    try {
      await axios.post('/api/exam/answer', {
        examId: exam._id,
        questionId,
        selectedAnswer
      });

      // Update local state
      setExam(prev => ({
        ...prev,
        questions: prev.questions.map(q => 
          q.questionId === questionId 
            ? { ...q, selectedAnswer }
            : q
        )
      }));

      toast.success('Answer saved!');
    } catch (error) {
      if (error.response?.data?.error === 'Exam has timed out') {
        setTimeUp(true);
        toast.error('Exam has timed out!');
        handleSubmitExam();
        return;
      }
      toast.error('Failed to save answer');
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < exam.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const handleSubmitExam = async () => {
    if (submitting) return;

    setSubmitting(true);
    try {
      const response = await axios.post('/api/exam/submit', {
        examId: exam._id
      });

      toast.success('Exam submitted successfully!');
      navigate(`/exam/result/${exam._id}`);
    } catch (error) {
      toast.error('Failed to submit exam');
      setSubmitting(false);
    }
  };

  const handleTimeUp = () => {
    setTimeUp(true);
    toast.error('Time is up! Submitting exam automatically...');
    handleSubmitExam();
  };

  if (loading) {
    return (
      <div className="loading">
        <div>Loading exam...</div>
      </div>
    );
  }

  if (!exam) {
    return (
      <div className="exam-error">
        <h2>No Active Exam</h2>
        <p>Please start a new exam from the dashboard.</p>
        <button 
          className="btn btn-primary"
          onClick={() => navigate('/dashboard')}
        >
          Go to Dashboard
        </button>
      </div>
    );
  }

  const currentQuestion = exam.questions[currentQuestionIndex];
  const answeredQuestions = exam.questions.filter(q => q.selectedAnswer !== null).length;
  const progress = (answeredQuestions / exam.totalQuestions) * 100;

  return (
    <div className="exam-interface">
      <div className="exam-header">
        <div className="exam-info">
          <h2>Exam in Progress</h2>
          <p>Category: {exam.category} | Difficulty: {exam.difficulty}</p>
        </div>
        <ExamTimer 
          duration={exam.duration * 60} 
          onTimeUp={handleTimeUp}
          remainingTime={exam.remainingTime}
        />
      </div>

      <div className="exam-progress">
        <div className="progress-bar">
          <div 
            className="progress-fill" 
            style={{ width: `${progress}%` }}
          ></div>
        </div>
        <div className="progress-text">
          Question {currentQuestionIndex + 1} of {exam.totalQuestions} 
          ({answeredQuestions} answered)
        </div>
      </div>

      <div className="exam-content">
        <QuestionCard
          question={currentQuestion}
          questionNumber={currentQuestionIndex + 1}
          onAnswerSelect={handleAnswerSelect}
          disabled={timeUp}
        />

        <div className="exam-navigation">
          <button
            className="btn btn-secondary"
            onClick={handlePreviousQuestion}
            disabled={currentQuestionIndex === 0 || timeUp}
          >
            <FaChevronLeft />
            Previous
          </button>

          <div className="question-indicators">
            {exam.questions.map((question, index) => (
              <button
                key={question.questionId}
                className={`question-indicator ${
                  index === currentQuestionIndex ? 'active' : ''
                } ${question.selectedAnswer !== null ? 'answered' : ''}`}
                onClick={() => setCurrentQuestionIndex(index)}
                disabled={timeUp}
              >
                {index + 1}
              </button>
            ))}
          </div>

          <button
            className="btn btn-secondary"
            onClick={handleNextQuestion}
            disabled={currentQuestionIndex === exam.questions.length - 1 || timeUp}
          >
            Next
            <FaChevronRight />
          </button>
        </div>

        <div className="exam-actions">
          <button
            className="btn btn-success"
            onClick={handleSubmitExam}
            disabled={submitting || timeUp}
          >
            {submitting ? 'Submitting...' : 'Submit Exam'}
            <FaCheck />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExamInterface; 